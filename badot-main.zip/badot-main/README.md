start by `docker compose up --build` 
